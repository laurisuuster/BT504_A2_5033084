/**
 * Enumeration for the players move
 */

public enum Player {
	Empty, Cross, Nought
}
